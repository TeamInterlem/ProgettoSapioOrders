YUI().use('aui-datatable',function(Y) {
	var columns = [
	               {key: 'Titolo'},
	               {key: 'Data'},
	               {key: 'Anteprima'},
	               {
	            	   key: 'Letto',
	            	   formatter: function(o){
	            		   o.rowClass = o.value == '0' ? 'nonletto' : o.rowClass;
	            		   o.rowClass = o.value == '1' ? 'letto' : o.rowClass;
	            		   }
	               }
	               ];
	
	var data = [
	            {'Titolo': 'Promozione Speciale su...', 'Data': '5 Set', 'Anteprima': 'Ciao Edoardo, abbiamo pensato una promozione speciale dedicata a te. Compra...','Letto': '0'},
	            {'Titolo': 'Spedizione ordine N.5856...', 'Data': '5 Set', 'Anteprima': 'Ciao Edoardo, il tuo ordine è stato spedito. Scarica il DDT al seguente indirizzo: ...','Letto': '0'},
	            {'Titolo': 'Pagamento in sospeso', 'Data': '30 Ago', 'Anteprima': 'Ciao Edoardo, il pagamento relativo all\'ordine 5856235 risulta non effettuato. Ti invitiamo...','Letto': '1'},
	            {'Titolo': 'Conferma d\'ordine N.5856...', 'Data': '28 Ago', 'Anteprima': 'Ciao Edoardo, il tuo ordine è stato registrato correttamente. Potrai verificare il suo stato...','Letto': '1'},
	            {'Titolo': 'Welcome su SAPIO Order!', 'Data': '27 Ago', 'Anteprima': 'Ciao Edoardo, benvenuto su Sapio Order. Scopri le funzionalità ed i benefici che...','Letto': '1'}
	            ];
	new Y.DataTable.Base({
		columnset: columns,
		recordset: data
		}).render('#notifiche_tabella');
	Y.on('domready', function(){
		$("*").removeClass("yui3-datatable-odd");
		$("*").removeClass("yui3-datatable-even");
		$("tr").css('cursor', 'pointer');
	});
	
});