$('#min-menu').click(function(){
	$("#portlet_menu_WAR_ProgettoSapioOrdersportlet").fadeToggle("800", "swing");
});

$('#min-menu, #cart-button').mouseenter(function(){
	$(this).addClass('menu-hover-pointer')
});

$('#min-menu, #cart-button').mouseleave(function(){
	$(this).removeClass('menu-hover-pointer')
});

$('#button-ordini').click(function(){
	window.location.replace("/web/guest/i-miei-ordini");
});

$('#button-prodotti').click(function(){
	window.location.replace("/web/guest/i-miei-prodotti");
});

$('#button-home').click(function(){
	window.location.replace("/web/guest/home");
});

$('#button-profilo').click(function(){
	window.location.replace("#");
});

$('#button-assistenza').click(function(){
	window.location.replace("/web/guest/assistenza");
});

$('#cart-button').click(function(){
	window.location.replace("/web/guest/carrello");
});