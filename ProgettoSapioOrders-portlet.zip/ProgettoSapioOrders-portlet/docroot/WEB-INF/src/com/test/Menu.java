package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Menu
 */
public class Menu extends MVCPortlet {
 

}
