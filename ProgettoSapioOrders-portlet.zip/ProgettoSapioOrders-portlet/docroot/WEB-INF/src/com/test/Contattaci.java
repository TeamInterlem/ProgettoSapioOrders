package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Contattaci
 */
public class Contattaci extends MVCPortlet {
 

}
