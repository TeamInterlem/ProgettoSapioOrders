package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Ordini
 */
public class Ordini extends MVCPortlet {
 

}
