package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Notifiche
 */
public class Notifiche extends MVCPortlet {
 

}
