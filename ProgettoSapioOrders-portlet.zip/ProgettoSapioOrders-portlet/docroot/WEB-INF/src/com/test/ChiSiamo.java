package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ChiSiamo
 */
public class ChiSiamo extends MVCPortlet {
 

}
