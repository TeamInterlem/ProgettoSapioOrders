package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Mail
 */
public class Mail extends MVCPortlet {
 

}
