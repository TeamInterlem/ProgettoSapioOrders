package com.test;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class Carrello
 */
public class Carrello extends MVCPortlet {
 

}
