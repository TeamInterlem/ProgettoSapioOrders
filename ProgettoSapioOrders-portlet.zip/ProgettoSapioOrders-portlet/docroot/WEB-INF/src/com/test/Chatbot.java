package com.test;

import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.service.BotService;

import java.io.IOException;
import java.io.PrintWriter;

import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

/**
 * Portlet implementation class Chatbot
 */
@SuppressWarnings("deprecation")
public class Chatbot extends MVCPortlet {
    @Override
    public void serveResource(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException,
            PortletException {

        String response = "[]";

        try
        {
            //User user = PortalUtil.getUser(resourceRequest);
            //String username = user.getScreenName();
            //ServiceContext serviceContext = ServiceContextFactory.getInstance(resourceRequest);
            if (resourceRequest.getResourceID().compareTo("inviaMessaggio")==0)
            {
                String request = ParamUtil.getString(resourceRequest, "request").split("\"message\":\"")[1].split("\"}")[0];
                response = "{\"msg\": \""+ BotService.getResponse(request) + "\"}";
            }
        }
        catch (Exception e)
        {
            response = "I'LL BE BACK.";
        }
        PrintWriter out=resourceResponse.getWriter();
        out.print(response);
    }
}
