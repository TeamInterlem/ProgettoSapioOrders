package com.service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Iterator;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BotService {

	private static String serverAccessToken = "WDDW25SWKUG3UZBQQXT7HNUPCKVGCSVV";
	private static String version = "20170126";
	private static String state = "stop"; //probabilmente non serve static
	private static String session_id; //probabilmente non serve static
	private static String O="";
	private static String context = "{}";

	public static String getResponse(String request) throws Exception
    {
        JSONObject o = new JSONObject(followConverse(request));
        String response = o.getString("response");
        return response;
    }
    
    public static String followConverse(String request) throws Exception
    {
    	
	   	String url = "https://api.wit.ai/converse";
    	String vers = "?v="+version;
    	String sess = "&session_id="+session_id;
    	String req = "";
    	
    	if(state.equals("stop")){
        	Random rand = new Random();
    		session_id = String.valueOf(Math.abs(rand.nextInt()));
    		req = "&q="+request;
    		req=req.replaceAll(" ", "%20");

    	}
	   	
	    URL obj = new URL(url+vers+sess+req);
	    HttpURLConnection conn = (HttpURLConnection) obj.openConnection();

	    conn.setDoOutput(true);
	    conn.setRequestMethod("POST");
  	    conn.setRequestProperty ("Content-Type", "application/json");
  	    conn.setRequestProperty ("Accept", "application/json");
	    conn.setRequestProperty ("Authorization", "Bearer "+serverAccessToken);

	    OutputStreamWriter out = new OutputStreamWriter(conn.getOutputStream());
	    out.write(context);
	    out.flush();
	    out.close();

        Reader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
        
        StringBuilder sb = new StringBuilder();
        for (int c; (c = in.read()) >= 0;)
            sb.append((char)c);
        String response = sb.toString();
        
        JSONObject o = new JSONObject(response);
        //String intent = o.getString("intent");
        state = o.getString("type");
        if(state.equals("merge")){
        	updContext(response);
        	followConverse("");
        }
        else if(state.equals("action")){
        	updContext(response);
        	String action = o.getString("action");
        	runAction(action);
        	followConverse("");
        }
        else if(state.equals("msg")){
        	O = o.getString("msg");
        	followConverse("");
    	}
        else if(state.equals("stop")){
        	//BOH
    	}
        return "{\"response\" : \""+O+"\"}";
	}

    public static void updContext(String response) throws Exception
    {
    	JSONObject cont = new JSONObject(context);
        JSONObject o = new JSONObject(response);
        JSONObject entities = o.getJSONObject("entities");
        Iterator<?> keys = entities.keys();

        while( keys.hasNext() ) {
        	String key = (String)keys.next();
            //JSONArray a = (JSONArray) entities.get(key);
            if ( entities.get(key) instanceof JSONArray ) {
            	for (int i = 0 ; i < ((JSONArray) entities.get(key)).length(); i++) {
            		 JSONObject obj = ((JSONArray) entities.get(key)).getJSONObject(i);
            		 String value = obj.getString("value");
            		 cont.put(key,value); //prendere solo miglior entities trovato per ogni tipo
            	 }
            }    	
        }
        context = cont.toString();
	}
    
    public static void runAction(String action) throws JSONException
    {
    	JSONObject cont = new JSONObject(context);
    	if(action.equals("preparaOrdine")){
			String gas ="";
			if (cont.has("gas") && !cont.isNull("gas")) {
				gas = cont.getString("gas");
			}
			if (cont.has("number") && !cont.isNull("number")) {
	   		 	String number = cont.getString("number");
			}
			if(gas.equals("Metano")){	cont.put("ordinePronto", "true");
										System.out.println("Ordine per "+cont.getString("number")+" bombole di "+cont.getString("gas")+" pronto." );}
			context = cont.toString();
    	}
    	else if(action.equals("ordina")){
    		if(cont.getString("yes_or_no").equals("SI")){
    			System.out.println("Ordine per "+cont.getString("number")+" bombole di "+cont.getString("gas")+" inviato!" );
    			cont.put("conferma", "TRUE");
    			cont.put("prodottoOrdinato", "TRUE");
    			cont.put("numeroOrdine", "0123456789");
    		}
    		else if(cont.getString("yes_or_no").equals("NO")){
    			System.out.println("Ordine per "+cont.getString("number")+" bombole di "+cont.getString("gas")+" cancellato!" );
    			cont.put("rifiuto", "TRUE");
    		}
			context = cont.toString();    		
    	}
    	else if(action.equals("pulisci")){
    		System.out.println("Ricordati di non dimenticare.");
    		context = "{\"pulito\":\"TRUE\"}";
    	}
    	else{
    		System.out.println("Azione non gestita. Contattare la US Robotics.");
    	}
    }
}